<script>
	let caso = ["nominativo","genitivo","dativo","acusativo","instrumental","preposicional"];
	//pasa un sustantivo de nominativo a cualquiera de los otros casos
	function casos(input,caso){
		switch (caso){
			case "genitivo":
			case "dativo":
				return "funcion solo disponible para caso acusativo"
			case "acusativo":
				if(comprobarGenero(input)=="femenino"){
					let resultadoAcusativo = input.split("")
					resultadoAcusativo.pop()
					resultadoAcusativo.push("C")
					return resultadoAcusativo.join("")
				}else{
					return input
				}
			case "instrumental":
			case "preposicional":
				return "funcion solo disponible para caso acusativo"
			default://"nominativo"
				return input
		}
	}
	let genero = ["masculino","femenino","neutro"];
	let plural = [true,false];
	//aca agregar las palabras que son excepciones a las reglas gramaticales establecidas
	let genericException = "2@5<O"
	//sirve para comprobar el genero de palabras en caso genitivo singular
	function comprobarGenero(input){
		if(input==genericException){
			return "es excepci�n"
		}else{
		//comprueba si la palabra es una excepci�n
// 		for(let i = 0; i > input.lenght; i++){
// 			if(input==genericException[i]){
// 				return "no puedo saber el genero de esta palabra porque es una excepci�n"
// 			}
//}
		let arrayInput = input.split("")
		switch(arrayInput[input.length-1]){
			case "0":
			case "O":
			 	return genero[1]
			case ">":
			case "5":
				return genero[2]
			case "L":
				return "este programa todavia no sabe distinguir el genero de las palabras terminadas en signo blando"
			default:
				return genero[0]
		}
		}
	}
</script>

<h1>
	el genero de la palabra es {comprobarGenero(":=830")}<br>
	en acusativo la palabra es {casos(":=830","acusativo")}
</h1>

<style>
	
</style>